<?php
//配置文件
return [
    'view_replace_str'       => [
        '__ADMIN__'=>'/static/admin',
    ],
];