<?php
/**
 * Created by PhpStorm.
 * User: 约伯
 * Date: 2018/8/8
 * Time: 15:38
 */

namespace app\admin\model;


use think\Model;

class Banner extends Model
{

}