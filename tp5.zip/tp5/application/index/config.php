<?php
/**
 * Created by PhpStorm.
 * User: 约伯
 * Date: 2018/8/13
 * Time: 16:55
 */

return [
    'view_replace_str'  =>  [
        '__INDEX__'=>'/static/index',
    ]
];