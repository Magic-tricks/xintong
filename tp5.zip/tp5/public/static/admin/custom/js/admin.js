/**
 * Created by yifeng on 2017/9/21.
 */
$(function () {

//    左侧菜单
    $('.layui-nav-item').on('click',function(){
        var obj=$(this);
        if($(obj).find('dl').first().hasClass('layui-nav-child')){
            $('.layui-nav-item').each(function () {
                $(this).removeClass('layui-nav-itemed');
            });
            $(obj).addClass('layui-nav-itemed');
        }
    });



})