<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:81:"D:\phpStudy\PHPTutorial\WWW\tp5\public/../application/index\view\story\story.html";i:1538980986;s:71:"D:\phpStudy\PHPTutorial\WWW\tp5\application\index\view\common\menu.html";i:1538987713;s:73:"D:\phpStudy\PHPTutorial\WWW\tp5\application\index\view\common\footer.html";i:1539073440;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>孔子文创</title>
		<link rel="stylesheet" type="text/css" href="/static/index/css/style.css"/>
		<!--<script src="./js/jquery.js"></script>-->
		<script type="text/javascript" src="/static/index/js/jquery1.42.min.js"></script>
		<script type="text/javascript" src="/static/index/js/jquery.SuperSlide.2.1.1.js"></script>
	</head>
	<body>
	<!--导航-->
<div class="nav">
    <ul class="clearfix">
        <img src="/static/index/images/logo.png"/>
        <?php if(is_array($cate) || $cate instanceof \think\Collection || $cate instanceof \think\Paginator): $i = 0; $__LIST__ = $cate;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <li <?php if($currtype == '0'): ?>class="current"<?php endif; ?>><a href="<?php echo makeurl($vo['type'],$vo['id']); ?>"><?php echo $vo['name']; ?></a></li>

        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
</div>
<!--banner-->

<div id="slideBox" class="slideBox">
    <!--<div class="hd">
        <ul><li>1</li><li>2</li><li>3</li></ul>
    </div>-->

    <div class="bd">

        <ul>
            <?php if(is_array($banner) || $banner instanceof \think\Collection || $banner instanceof \think\Paginator): $i = 0; $__LIST__ = $banner;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <li><a href="<?php echo $vo['url']; ?>" target="_blank"><img src="/<?php echo $vo['pic']; ?>" /></a></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>

    </div>

    <!-- 下面是前/后按钮代码，如果不需要删除即可 -->
    <a class="prev" href="javascript:void(0)"></a>
    <a class="next" href="javascript:void(0)"></a>

</div>

<script type="text/javascript">
    jQuery(".slideBox").slide({mainCell:".bd ul",effect:"fold",autoPlay:true});
</script>

		<!--模块1-->
		<div class="mk1 clearfix">
			<p class="tit1">PRODUCE   STROY</p>
			<p class="tit2">产品<span class="bold">故事</span></p>
			<div class="story-box clearfix">
				<div class="story-img">
					<img src="/static/index/images/list1.jpg"/>
				</div>
				<div class="story-main">
					<p class="sty-tit">历经5年，年收破10亿，故宫文创的未来之路在哪里？</p>
					<p class="sty-con">作为中国大陆第一家走红的博物馆文创，公开数据显示，截止2016年底，故宫博物馆的文创产品已达到9170种，而仅2016年一年就为故宫带来了10亿元左右的收入。<br />这让率先「出道」的台北故宫文创感到心酸，大陆怎么就悄无声息的超过我们了呢？<br />在一些台媒眼里，北京故宫的成功是师从台北故宫。<br />2013年，台北故宫推出了一系列「朕知道了」的纸胶带，大陆的小伙伴纷纷上淘宝求海峡对岸的代购，原价42元一盒的纸胶带被炒到人民币98元，还一度断货，当年的销售量超过18万件。</p>
				</div>
			</div>
			<div class="story-box">
				<div class="story-main2">
					<p class="sty-tit">历经5年，年收破10亿，故宫文创的未来之路在哪里？</p>
					<p class="sty-con">作为中国大陆第一家走红的博物馆文创，公开数据显示，截止2016年底，故宫博物馆的文创产品已达到9170种，而仅2016年一年就为故宫带来了10亿元左右的收入。<br />这让率先「出道」的台北故宫文创感到心酸，大陆怎么就悄无声息的超过我们了呢？<br />在一些台媒眼里，北京故宫的成功是师从台北故宫。<br />2013年，台北故宫推出了一系列「朕知道了」的纸胶带，大陆的小伙伴纷纷上淘宝求海峡对岸的代购，原价42元一盒的纸胶带被炒到人民币98元，还一度断货，当年的销售量超过18万件。</p>
				</div>
				<div class="story-img2">
					<img src="/static/index/images/list1.jpg"/>
				</div>
			</div>
			
		</div>


	<!--底部-->
<div class="foot-bj"></div>
<div class="footer">
    <ul>
        <li><img src="/static/index/images/foot_logo.png"/></li>
        <li>
            <a href="javascript:volid(0);">首页</a>
            <a href="javascript:volid(0);">产品故事</a>
            <a href="javascript:volid(0);">产品展示</a>
            <a href="javascript:volid(0);">联系我们</a>
        </li>
        <li></li>
    </ul>
</div>
		
	</body>
</html>
