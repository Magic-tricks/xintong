<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:81:"D:\phpStudy\PHPTutorial\WWW\tp5\public/../application/index\view\index\index.html";i:1539074220;s:71:"D:\phpStudy\PHPTutorial\WWW\tp5\application\index\view\common\menu.html";i:1538987713;s:73:"D:\phpStudy\PHPTutorial\WWW\tp5\application\index\view\common\footer.html";i:1539073440;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>孔子文创</title>
	<link rel="stylesheet" type="text/css" href="/static/index/css/style.css"/>
	<!--<script src="./js/jquery.js"></script>-->
	<script type="text/javascript" src="/static/index/js/jquery1.42.min.js"></script>
	<script type="text/javascript" src="/static/index/js/jquery.SuperSlide.2.1.1.js"></script>
</head>
<body>
<!--导航-->
<div class="nav">
    <ul class="clearfix">
        <img src="/static/index/images/logo.png"/>
        <?php if(is_array($cate) || $cate instanceof \think\Collection || $cate instanceof \think\Paginator): $i = 0; $__LIST__ = $cate;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <li <?php if($currtype == '0'): ?>class="current"<?php endif; ?>><a href="<?php echo makeurl($vo['type'],$vo['id']); ?>"><?php echo $vo['name']; ?></a></li>

        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
</div>
<!--banner-->

<div id="slideBox" class="slideBox">
    <!--<div class="hd">
        <ul><li>1</li><li>2</li><li>3</li></ul>
    </div>-->

    <div class="bd">

        <ul>
            <?php if(is_array($banner) || $banner instanceof \think\Collection || $banner instanceof \think\Paginator): $i = 0; $__LIST__ = $banner;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <li><a href="<?php echo $vo['url']; ?>" target="_blank"><img src="/<?php echo $vo['pic']; ?>" /></a></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>

    </div>

    <!-- 下面是前/后按钮代码，如果不需要删除即可 -->
    <a class="prev" href="javascript:void(0)"></a>
    <a class="next" href="javascript:void(0)"></a>

</div>

<script type="text/javascript">
    jQuery(".slideBox").slide({mainCell:".bd ul",effect:"fold",autoPlay:true});
</script>

<!--模块1-->
<div class="mk1 clearfix">
	<p class="tit1">PRODUCE   STROY</p>
	<p class="tit2">产品<span class="bold">故事</span></p>
	<dl class="flex mk1-imgs">
		<dd><a href="javascript:volid(0);"><img src="/static/index/images/main.jpg"/></a></dd>
		<dd><a href="javascript:volid(0);"><img src="/static/index/images/main.jpg"/></a></dd>
		<dd><a href="javascript:volid(0);"><img src="/static/index/images/main.jpg"/></a></dd>
		<dd><a href="javascript:volid(0);"><img src="/static/index/images/main.jpg"/></a></dd>
		<dd><a href="javascript:volid(0);"><img src="/static/index/images/main.jpg"/></a></dd>
	</dl>
</div>
<!--通栏banner-->
<div class="main-banner">
	<a href="javascript:volid(0);"><img src="/static/index/images/banner1.jpg"/></a>
</div>
<!--模块2-->
<div class="mk1 clearfix">
	<p class="tit1">MEET THE CREATIVES</p>
	<p class="tit2">旅游纪念品</p>
	<dl class="flex mk2-imgs">
		<dd>
			<a href="javascript:volid(0);"><img src="/static/index/images/list1.jpg"/></a>
			<p class="mk2-con">James McCalister</p>
			<p class="mk2-con2">Creative Director</p>
		</dd>
		<dd>
			<a href="javascript:volid(0);"><img src="/static/index/images/list2.jpg"/></a>
			<p class="mk2-con">Jane Wiskerson</p>
			<p class="mk2-con2">Web and Mobile Designer</p>
		</dd>
		<dd>
			<a href="javascript:volid(0);"><img src="/static/index/images/list3.jpg"/></a>
			<p class="mk2-con">Mariana Kowalsky</p>
			<p class="mk2-con2">Software Developer</p>
		</dd>
	</dl>
</div>
<!--通栏banner-->
<div class="main-banner">
	<a href="javascript:volid(0);"><img src="/static/index/images/banner2.jpg"/></a>
</div>
<!--模块2-->
<div class="mk1 clearfix">
	<p class="tit1">MEET THE CREATIVES</p>
	<p class="tit2">文具</p>
	<dl class="flex mk2-imgs">
		<dd>
			<a href="javascript:volid(0);" onmousedown="this.className'aaa'"><img src="/static/index/images/list1.jpg"/></a>
			<p class="mk2-con">James McCalister</p>
			<p class="mk2-con2">Creative Director</p>
		</dd>
		<dd>
			<a href="javascript:volid(0);"><img src="/static/index/images/list2.jpg"/></a>
			<p class="mk2-con">Jane Wiskerson</p>
			<p class="mk2-con2">Web and Mobile Designer</p>
		</dd>
		<dd>
			<a href="javascript:volid(0);"><img src="/static/index/images/list3.jpg"/></a>
			<p class="mk2-con">Mariana Kowalsky</p>
			<p class="mk2-con2">Software Developer</p>
		</dd>
	</dl>
</div>
<!--通栏banner-->
<div class="main-banner">
	<a href="javascript:volid(0);"><img src="/static/index/images/banner3.jpg"/></a>
</div>
<!--模块2-->
<div class="mk1 clearfix">
	<p class="tit1">MEET THE CREATIVES</p>
	<p class="tit2">日用品</p>
	<dl class="flex mk2-imgs">
		<dd>
			<a href="javascript:volid(0);"><img src="/static/index/images/list1.jpg"/></a>
			<p class="mk2-con">James McCalister</p>
			<p class="mk2-con2">Creative Director</p>
		</dd>
		<dd>
			<a href="javascript:volid(0);"><img src="/static/index/images/list2.jpg"/></a>
			<p class="mk2-con">Jane Wiskerson</p>
			<p class="mk2-con2">Web and Mobile Designer</p>
		</dd>
		<dd>
			<a href="javascript:volid(0);"><img src="/static/index/images/list3.jpg"/></a>
			<p class="mk2-con">Mariana Kowalsky</p>
			<p class="mk2-con2">Software Developer</p>
		</dd>
	</dl>
</div>

<!--底部-->
<div class="foot-bj"></div>
<div class="footer">
    <ul>
        <li><img src="/static/index/images/foot_logo.png"/></li>
        <li>
            <a href="javascript:volid(0);">首页</a>
            <a href="javascript:volid(0);">产品故事</a>
            <a href="javascript:volid(0);">产品展示</a>
            <a href="javascript:volid(0);">联系我们</a>
        </li>
        <li></li>
    </ul>
</div>

</body>
</html>
